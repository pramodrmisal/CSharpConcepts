﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20_namespaces.bank
{
    public class Account
    {
        public void Print()
        {
            Console.WriteLine("Account Print() method");
        }
    }
}
