﻿namespace _20_namespaces.school
{
    public class Student
    {
        public void Print()
        {
            Customer customer = new Customer();
            Console.WriteLine("Student Print() method");
        }
    }
}
