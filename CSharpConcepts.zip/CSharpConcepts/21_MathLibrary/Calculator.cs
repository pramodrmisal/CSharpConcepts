﻿namespace Calucations
{
    public class Calculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public int Division(int num, int den)
        {
            return num / den;
        }
    }
}