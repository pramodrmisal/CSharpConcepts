﻿#region List<> Collection class

//List<int> numbers = new List<int>();
//numbers.Add(10);
//numbers.Add(20);
//numbers.Add(30);

//Console.WriteLine("Elements In List");
//foreach (int item in numbers)
//{
//    Console.Write($"{item} ");
//}
//Console.WriteLine(); // new line

#endregion List<> Collection class

#region Dictionary<> Collection class

//Dictionary<int, string> students = new Dictionary<int, string>();
//students.Add(1, "Vishal");
//students.Add(2, "Anil");

//// foreach (var item in students)
//// foreach (object item in students) // not recommended
//// foreach (dynamic item in students)
//foreach (KeyValuePair<int, string> item in students)
//{
//    Console.WriteLine($"Key : {item.Key} Value : {item.Value}");
//}

//string name = students[2];
//Console.WriteLine($"Value of Key 2 is {name}");

#endregion Dictionary<> Collection class

#region Stack<> Collection class

//Stack<string> lift = new Stack<string>();
//lift.Push("Anil");
//lift.Push("Rahul");

//string name = lift.Pop();
//Console.WriteLine(name); // Rahul

//name = lift.Peek();
//Console.WriteLine(name); // Anil

#endregion Stack<> Collection class

#region Queue<> Collection class

//Queue<string> atm = new Queue<string>();
//atm.Enqueue("Vishal");
//atm.Enqueue("Mahesh");

//string name1 = atm.Dequeue();
//string name2 = atm.Peek();

#endregion Queue<> Collection class



Console.ReadLine();