﻿class Student
{
    void Print()
    {

    }

    int RollNumber;
}