﻿public class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Experience { get; set; }
    public string Gender { get; set; }
    public string DepartmentName { get; set; }




}