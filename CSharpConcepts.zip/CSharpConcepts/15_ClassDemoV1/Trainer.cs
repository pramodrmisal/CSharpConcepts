﻿public class Trainer
{
    public string Name;
    public int ExperienceInYear;

    public void PrintTrainerDetails()
    {
        Console.WriteLine($"Name : {Name}\nExperience : {ExperienceInYear}");
    }
}